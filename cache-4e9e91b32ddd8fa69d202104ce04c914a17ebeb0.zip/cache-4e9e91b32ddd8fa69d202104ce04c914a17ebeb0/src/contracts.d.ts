export interface ArtifactCacheEntry {
    cacheKey?: string;
    scope?: string;
    creationTime?: string;
    archiveLocation?: string;
}
